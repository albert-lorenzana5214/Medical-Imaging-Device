function [ out ] = butterlp( im,d,n)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
out=1-butterhp(im,d,n);
end
